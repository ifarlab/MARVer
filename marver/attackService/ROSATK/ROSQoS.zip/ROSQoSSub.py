#!/usr/bin/env python
from pickle import FALSE
import time
import rospy
from rospy.impl.rosout import RosOutHandler
from std_msgs.msg import String
import datetime
import os
import csv
import threading as th

count = 0
curTime = time.time()

lst_ros = []
lst_csv = []

logfile = open('ros.csv', mode='w')
logwriter = csv.writer(logfile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

def bw():
     os.system("rostopic bw /QoS")

def hz():
     os.system("rostopic hz /QoS")

def callback(data):
    global lst_ros, lst_csv
    lst_ros.append(data)
    """
    global count, logfile
    global curTime
    count +=1
    if count >= 100:
        print("Delay :", ((time.time_ns() - int(data.data)) //100000), "ms |","Frequency :", "{:.2f}".format(100 / (time.time() - curTime)), "| Datetime :" ,datetime.datetime.now())
        #logwriter.writerow(['Delay(ms)', str(((time.time_ns() - int(data.data)) //100000)), str('Frequency(hz)'), str("{:.2f}".format(100 / (time.time() - curTime))), str('Datetime'), str(datetime.datetime.now())])
        #print("Delay :", "{:.2f}".format((rospy.get_time() - float(data.data)) * 1000), "ms |","Frequency :", "{:.2f}".format(100 / (time.time() - curTime)), "| Datetime :" ,datetime.datetime.now())
        curTime = time.time()
        count = 0

    """
def csv_packager(sample_time = 5):
    global lst_ros, lst_csv
    while True:
        packTime = time.time() + sample_time
        
        while time.time() <= packTime:
            if len(lst_ros) > 0:
                lst_csv.append(lst_ros.pop(0))
        
        print(len(lst_csv) / sample_time)
        lst_csv.clear()


def listener():
    rospy.init_node('ROSQoSSub', anonymous=True)

    rospy.Subscriber("QoS", String, callback)

    try:
        customFrequency = th.Thread(target=csv_packager)
        customFrequency.start()
    except:
        print("Multi threading error!")


    """
    bandwith = mp.Process(target=bw)
    bandwith.start()
    frequency = mp.Process(target=hz)
    frequency.start()
    """
    rospy.spin()
    

if __name__ == '__main__':
    listener()